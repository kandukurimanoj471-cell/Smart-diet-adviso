from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# LOGIN PAGE
@app.route('/')
def login():
    return render_template('login.html')


# LOGIN VALIDATION
@app.route('/login', methods=['POST'])
def login_user():

    username = request.form['username']
    password = request.form['password']

    # demo login
    if username and password:
        return redirect(url_for('bmi'))

    return redirect(url_for('login'))


# BMI PAGE
@app.route('/bmi')
def bmi():
    return render_template('bmi.html')


# BMI RESULT
@app.route('/bmi_result', methods=['POST'])
def bmi_result():

    name = request.form['name']
    height = float(request.form['height']) / 100
    weight = float(request.form['weight'])

    bmi = round(weight / (height * height), 2)

    if bmi < 18.5:
        status = "Underweight"
    elif bmi < 25:
        status = "Normal"
    elif bmi < 30:
        status = "Overweight"
    else:
        status = "Obese"

    return render_template(
        'bmi_result.html',
        bmi=bmi,
        status=status,
        name=name
    )


# BODY TYPE
@app.route('/body_type', methods=['POST'])
def body_type():

    goal = request.form['goal']

    return render_template(
        'body_type.html',
        goal=goal
    )


# DIET RESULT
# FINAL DIET RESULT
@app.route('/diet_result', methods=['POST'])
def diet_result():

    goal = request.form['goal']
    body = request.form['body']

    # =========================
    # WEIGHT GAIN DIETS
    # =========================

    if goal == "Weight Gain":

        # ECTOMORPH
        if body == "Ectomorph":

            diet = {

                "6:00 AM":
                "Warm water + banana + almonds",

                "8:00 AM":
                "Oats + peanut butter + 4 eggs + milk",

                "11:00 AM":
                "Protein shake + dry fruits",

                "1:00 PM":
                "Rice + chicken + potatoes + vegetables",

                "5:00 PM":
                "Banana shake + peanuts",

                "8:00 PM":
                "Chapati + paneer + rice",

                "10:00 PM":
                "Milk + dates"
            }

        # MESOMORPH
        elif body == "Mesomorph":

            diet = {

                "6:00 AM":
                "Warm water + walnuts",

                "8:00 AM":
                "Eggs + oats + fruits",

                "11:00 AM":
                "Protein shake",

                "1:00 PM":
                "Rice + chicken breast + vegetables",

                "5:00 PM":
                "Boiled eggs + banana",

                "8:00 PM":
                "Chapati + paneer + salad",

                "10:00 PM":
                "Milk"
            }

        # ENDOMORPH
        else:

            diet = {

                "6:00 AM":
                "Warm lemon water",

                "8:00 AM":
                "Oats + boiled eggs",

                "11:00 AM":
                "Green tea + apple",

                "1:00 PM":
                "Brown rice + chicken + vegetables",

                "5:00 PM":
                "Protein shake",

                "8:00 PM":
                "Salad + paneer",

                "10:00 PM":
                "Warm water"
            }

    # =========================
    # WEIGHT LOSS DIETS
    # =========================

    else:

        # ECTOMORPH
        if body == "Ectomorph":

            diet = {

                "6:00 AM":
                "Warm lemon water",

                "8:00 AM":
                "Oats + fruits",

                "11:00 AM":
                "Apple + green tea",

                "1:00 PM":
                "Brown rice + vegetables",

                "5:00 PM":
                "Soup + peanuts",

                "8:00 PM":
                "Salad + soup",

                "10:00 PM":
                "Warm water"
            }

        # MESOMORPH
        elif body == "Mesomorph":

            diet = {

                "6:00 AM":
                "Warm water + almonds",

                "8:00 AM":
                "Boiled eggs + oats",

                "11:00 AM":
                "Fruit juice",

                "1:00 PM":
                "Grilled chicken + vegetables",

                "5:00 PM":
                "Green tea + nuts",

                "8:00 PM":
                "Soup + salad",

                "10:00 PM":
                "Warm water"
            }

        # ENDOMORPH
        else:

            diet = {

                "6:00 AM":
                "Warm lemon water",

                "8:00 AM":
                "Oats + boiled egg whites",

                "11:00 AM":
                "Green tea",

                "1:00 PM":
                "Brown rice + grilled chicken + vegetables",

                "5:00 PM":
                "Apple + black coffee",

                "8:00 PM":
                "Salad + soup",

                "10:00 PM":
                "Warm water"
            }

    return render_template(
        'diet_result.html',
        goal=goal,
        body=body,
        diet=diet
    )


if __name__ == '__main__':
    app.run(debug=True)